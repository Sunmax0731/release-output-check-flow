# 出力・リリース確認フロー 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 9 |
| 分野 | リリース・公開 |
| アイデア | 出力・リリース確認フロー |
| リポジトリ名 | release-output-check-flow |
| 概要 | 命名、形式、出力先、公開前チェック、レポート生成をまとめる。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。 |
| 課題 | 納品や公開前の確認が手作業に寄り、抜け漏れが残りやすい。 |
| 類似サービス・アプリ | GitHub Projects, Linear, Jira, GitHub Actions, Codex, Claude Code, Cursor |
| 差別化ポイント | Issue、PR、設計ドキュメント、エージェント作業、リリース証跡を同じ流れで扱う。 出力プレビュー、命名規則、公開証跡を1フローにする。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `出力・リリース確認フロー` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
