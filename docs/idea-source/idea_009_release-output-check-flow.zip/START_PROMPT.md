あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Apps
- 領域: ProjectManagement
- No.: 9
- 分野: リリース・公開
- アイデア: 出力・リリース確認フロー
- リポジトリ名: release-output-check-flow

## 元アイデア

- 概要: 命名、形式、出力先、公開前チェック、レポート生成をまとめる。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。
- 課題: 納品や公開前の確認が手作業に寄り、抜け漏れが残りやすい。
- 類似サービス・アプリ: GitHub Projects, Linear, Jira, GitHub Actions, Codex, Claude Code, Cursor
- 差別化ポイント: Issue、PR、設計ドキュメント、エージェント作業、リリース証跡を同じ流れで扱う。 出力プレビュー、命名規則、公開証跡を1フローにする。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- 主要ユーザー、ローカル保存、権限、バックアップ、外部API境界を明確にする。
- 入力から確認、履歴、出力までの一連の流れを設計する。
- 日常利用フロー、データ復旧、プライバシーに関わる挙動を検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
